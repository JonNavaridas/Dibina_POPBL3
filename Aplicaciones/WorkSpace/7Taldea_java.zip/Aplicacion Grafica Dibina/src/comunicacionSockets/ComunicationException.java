package comunicacionSockets;

public class ComunicationException extends Exception {

	private static final long serialVersionUID = 1L;

	public ComunicationException(String msg) {
		super(msg);
	}
}
